package kz.spring.workflow.request;

import lombok.Data;

@Data
public class LoginRequest {

    String Username;
    String Password;


}
