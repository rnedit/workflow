package kz.spring.workflow.domain;

public enum EAccessProfile {
        ACCESS_CREATEDOCUMENT,
        ACCESS_CREATEPROFILE,
        ACCESS_DELETEPROFILE,
        ACCESS_CREATEUSER,
        ACCESS_DELETEUSER,

        ACCESS_STRUCT,
        ACCESS_SPRAV,
        ACCESS_OUTDOC,
        ACCESS_INDOC,
        ACCESS_SZ,
        ACCESS_ORD,


        ACCESS_ALL //для админа
}
