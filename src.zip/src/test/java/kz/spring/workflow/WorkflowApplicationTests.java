package kz.spring.workflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkflowApplicationTests {

    @Test
    void contextLoads() {
    }

}
